#!/bin/bash
SAVEIFS=$IFS
IFS=$(echo -en "\n\b")
echo $IFS"11111111111111"

for dir in `ls -l`
do
	echo $dir
done
IFS=$SAVEIFS
